from pydantic import BaseModel

class AlunoCreate(BaseModel):
    nome: str

class AlunoUpdate(BaseModel):
    nome: str
