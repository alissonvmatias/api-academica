from pydantic import BaseModel, Field

class NotaCreate(BaseModel):
    aluno_id: int
    valor: float = Field(..., ge=0, le=10)
