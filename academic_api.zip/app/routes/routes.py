from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.db import SessionLocal
from app.schemas.aluno_schema import AlunoCreate, AlunoUpdate
from app.schemas.nota_schema import NotaCreate
from app.controllers import aluno_controller, nota_controller

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/alunos")
def criar_aluno(aluno: AlunoCreate, db: Session = Depends(get_db)):
    try:
        return aluno_controller.criar_aluno(db, aluno.nome)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/alunos")
def listar(db: Session = Depends(get_db)):
    return aluno_controller.listar_alunos(db)

@router.put("/alunos/{aluno_id}")
def atualizar(aluno_id: int, aluno: AlunoUpdate, db: Session = Depends(get_db)):
    try:
        return aluno_controller.atualizar_aluno(db, aluno_id, aluno.nome)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/alunos/{aluno_id}")
def deletar(aluno_id: int, db: Session = Depends(get_db)):
    try:
        return aluno_controller.deletar_aluno(db, aluno_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/notas")
def lancar_nota(nota: NotaCreate, db: Session = Depends(get_db)):
    try:
        return nota_controller.lancar_nota(db, nota.aluno_id, nota.valor)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/alunos/{aluno_id}/situacao")
def situacao(aluno_id: int, db: Session = Depends(get_db)):
    return nota_controller.calcular_situacao(db, aluno_id)
